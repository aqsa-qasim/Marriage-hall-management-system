﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.OleDb;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using static System.Windows.Forms.VisualStyles.VisualStyleElement;


namespace WindowsFormsApp1
{
    public partial class Form7 : Form
    {
        OleDbConnection conn;
        OleDbCommand cmd;
        OleDbDataAdapter adapter;
        OleDbDataReader reader;
        DataTable dt;


        public Form7()
        {
            InitializeComponent();
        }

        private void Form7_Load(object sender, EventArgs e)
        {
            GetStaff();

        }

        void GetStaff()
        {
            conn = new OleDbConnection("Provider=Microsoft.ACE.OLEDB.12.0;Data Source=\"C:\\Program Files\\Default Company Name\\Marriage Setup\\Marriage.accdb\"");
            dt = new DataTable();
            adapter = new OleDbDataAdapter("SELECT * FROM Staff", conn);
            conn.Open();
            adapter.Fill(dt);
            dataGridView2.DataSource = dt;
            conn.Close();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            string query = "INSERT INTO Staff(StaffName,StaffPhone,StaffGender,Password)" +
            "VALUES (@staffname, @staffphone, @staffgender, @password)";
            cmd = new OleDbCommand(query, conn);
            cmd.Parameters.AddWithValue("@staffname", textBox8.Text);
            cmd.Parameters.AddWithValue("@staffphone", textBox1.Text);
            cmd.Parameters.AddWithValue("@staffgender", textBox2.Text);
            cmd.Parameters.AddWithValue("@password", textBox3.Text);
          

            conn.Open();
            cmd.ExecuteNonQuery();
            MessageBox.Show("INSERT SUCCESSFULLY");
            GetStaff();
            conn.Close();

        }

        private void button2_Click(object sender, EventArgs e)
        {
            string query = "UPDATE Staff SET StaffPhone=@staffphone, StaffGender=@staffgender, [Password]=@password WHERE StaffName=@staffname";
            using (OleDbConnection conn = new OleDbConnection("Provider=Microsoft.ACE.OLEDB.12.0;Data Source=\"C:\\Program Files\\Default Company Name\\Marriage Setup\\Marriage.accdb\""))
            {
                using (OleDbCommand cmd = new OleDbCommand(query, conn))
                {
                    cmd.Parameters.AddWithValue("@staffname", textBox8.Text);
                    cmd.Parameters.AddWithValue("@staffphone", textBox1.Text);
                    cmd.Parameters.AddWithValue("@staffgender", textBox2.Text);
                    cmd.Parameters.AddWithValue("@password", textBox3.Text);
                   

                    conn.Open();
                    cmd.ExecuteNonQuery();
                    MessageBox.Show("UPDATE SUCCESSFULLY");
                    GetStaff();
                }
            }




                }

                private void button3_Click(object sender, EventArgs e)
        {
            String query = "DELETE FROM Staff WHERE Id=@id";

            using (OleDbConnection conn = new OleDbConnection("Provider=Microsoft.ACE.OLEDB.12.0;Data Source=\"C:\\Program Files\\Default Company Name\\Marriage Setup\\Marriage.accdb\"")) 
            {
                using (OleDbCommand cmd = new OleDbCommand(query, conn)) 
                {
                    cmd.Parameters.AddWithValue("@staffname", textBox8.Text);
                    conn.Open();
                    cmd.ExecuteNonQuery();
                    MessageBox.Show("Delete Successfully");
                    GetStaff();
                }
            }

        }

        private void button4_Click(object sender, EventArgs e)
        {
            textBox8.Text = "";
            textBox1.Text = "";
            textBox2.Text = "";
            textBox3.Text = "";
        }

        private void dataGridView2_CellEnter(object sender, DataGridViewCellEventArgs e)
        {
            textBox8.Text = dataGridView2.CurrentRow.Cells[0].Value.ToString();
            textBox1.Text = dataGridView2.CurrentRow.Cells[1].Value.ToString();
            textBox2.Text = dataGridView2.CurrentRow.Cells[2].Value.ToString();
            textBox3.Text = dataGridView2.CurrentRow.Cells[3].Value.ToString();
        }
    }
    
}
    

