﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.OleDb;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;



namespace WindowsFormsApp1
{
    public partial class Form6 : Form
    {
        OleDbConnection conn;
        OleDbCommand cmd;
        OleDbDataAdapter adapter;
        OleDbDataReader reader;
        DataTable dt;
       
        
        public Form6()
        {
            InitializeComponent();
        }
        void GetCustomer()
        {
            
            conn = new OleDbConnection("Provider=Microsoft.ACE.OLEDB.12.0;Data Source=\"C:\\Program Files\\Default Company Name\\Marriage Setup\\Marriage.accdb\"");
            dt = new DataTable();
            adapter = new OleDbDataAdapter("SELECT *FROM Customer", conn);
            adapter.Fill(dt);
            conn.Open();
            dataGridView1.DataSource = dt;
            conn.Close();
        }

        private void button1_Click(object sender, EventArgs e)
        {

            string query = "INSERT INTO Customer(CusName, CusAddress, CusPhone) VALUES (@cusname, @cusaddress, @cusphone)";
            using (OleDbConnection conn = new OleDbConnection("Provider=Microsoft.ACE.OLEDB.12.0;Data Source=\"C:\\Program Files\\Default Company Name\\Marriage Setup\\Marriage.accdb\"")) 
            {
                using (OleDbCommand cmd = new OleDbCommand(query, conn))
                {
                    cmd.Parameters.AddWithValue("@cusname", textBox8.Text);
                    cmd.Parameters.AddWithValue("@cusaddress", textBox1.Text);
                    cmd.Parameters.AddWithValue("@cusphone", textBox2.Text);
                    

                    conn.Open();
                    cmd.ExecuteNonQuery();
                    MessageBox.Show("INSERT SUCCESSFULLY");
                    GetCustomer();

                }
            }
        }

                private void Form6_Load(object sender, EventArgs e)
        {
            GetCustomer();
        }

        private void button2_Click(object sender, EventArgs e)
        {
            String query = "UPDATE Customer SET CusName=@cusname,CusAddress=@cusaddress,CusPhone=@cusphone WHERE CusName=@cusname";
            cmd = new OleDbCommand(query, conn);
            cmd.Parameters.AddWithValue("@cusname", textBox8.Text);
            cmd.Parameters.AddWithValue("@cusaddresss", textBox1.Text);
            cmd.Parameters.AddWithValue("@cusphone", textBox2.Text);
            conn.Open();
            cmd.ExecuteNonQuery();
            MessageBox.Show("UPDATE SUCCESSFULLY");
            GetCustomer();
            conn.Close();

        }

        private void button3_Click(object sender, EventArgs e)
        {

            string query = "DELETE FROM Customer WHERE Id=@id";
            using (OleDbConnection conn = new OleDbConnection("Provider=Microsoft.ACE.OLEDB.12.0;Data Source=\\\"C:\\\\Program Files\\\\Default Company Name\\\\Marriage Setup\\\\Marriage.accdb\\\"\")) \r\n            {"))
            {
                using (OleDbCommand cmd = new OleDbCommand(query, conn))
                {
                    cmd.Parameters.AddWithValue("@cusname", textBox8.Text);

                    conn.Open();
                    cmd.ExecuteNonQuery();
                    MessageBox.Show("DELETE SUCCESSFULLY");
                    GetCustomer();
                }

            }
        }

            private void dataGridView1_CellEnter(object sender, DataGridViewCellEventArgs e)
        {
            textBox8.Text = dataGridView1.CurrentRow.Cells[0].Value.ToString();
            textBox1.Text = dataGridView1.CurrentRow.Cells[1].Value.ToString();
            textBox2.Text = dataGridView1.CurrentRow.Cells[2].Value.ToString();
        }

        private void button4_Click(object sender, EventArgs e)
        {
            textBox8.Text = "";
            textBox1.Text = "";
            textBox2.Text = "";
        }

        private void button5_Click(object sender, EventArgs e)
        {
                
                this.Close();
            }
        }
    }

