﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Diagnostics.Eventing.Reader;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace WindowsFormsApp1
{
    public partial class Form8 : Form
    {
        public Form8()
        {
            InitializeComponent();
        }

        private void label3_Click(object sender, EventArgs e)
        {

        }

        private void button1_Click(object sender, EventArgs e)
        {
            if(textBox3.Text=="")
            {
                MessageBox.Show("Enter the admin password");
            }
            else if (textBox3.Text == "Ayesha") 
            {
                Form7 f7=new Form7();
                f7.Show();
                this.Hide();
            }
             else
            {
                MessageBox.Show("wrong Password***Contact the Admin of this System");
            }


         

        }

        private void Form8_Load(object sender, EventArgs e)
        {

        }
    }
}
